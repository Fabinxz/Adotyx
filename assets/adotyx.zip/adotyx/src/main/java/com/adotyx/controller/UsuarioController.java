package com.adotyx.controller;

import com.adotyx.model.domain.Animal;
import com.adotyx.model.domain.Usuario;
import com.adotyx.model.dao.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private AnimalRepository animalRepository;

    @PostMapping("/cadastrar")
    public Usuario cadastrarUsuario(@RequestBody Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    @GetMapping("/listar")
    public List<Usuario> listarUsuarios() {
        return usuarioRepository.findAll();
    }

    @GetMapping("/buscarPorId/{id}")
    public Usuario buscarUsuarioPorId(@PathVariable("id") int id) {
        return usuarioRepository.findById(id).orElse(null);
    }

    @DeleteMapping("/deletar/{id}")
    public void deletarUsuario(@PathVariable("id") int id) {
        usuarioRepository.deleteById(id);
    }

    @GetMapping("/adicionarAnimal/{idUsuario}/{idAnimal}")
    public ResponseEntity<String> adicionarAnimalAoUsuario(@PathVariable("idUsuario") int idUsuario, @PathVariable("idAnimal") int idAnimal) {
        Usuario usuario = usuarioRepository.findById(idUsuario).orElse(null);
        Animal animal = animalRepository.findById(idAnimal).orElse(null);
        
        if (usuario != null && animal != null) {
            usuario.addAnimal(animal);
            usuarioRepository.save(usuario);
            return ResponseEntity.ok("Animal adicionado com sucesso ao usuário com ID: " + idUsuario);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}