package com.adotyx.controller;

import com.adotyx.model.domain.Animal;
import com.adotyx.model.dao.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/animais")
public class AnimalController {

    @Autowired
    private AnimalRepository animalRepository;

    @PostMapping("/cadastrar")
    public Animal cadastrarAnimal(@RequestBody Animal animal) {
        return animalRepository.save(animal);
    }

    @GetMapping("/listar")
    public List<Animal> listarAnimais() {
        return animalRepository.findAll();
    }

    @GetMapping("/buscarPorId/{id}")
    public Animal buscarAnimalPorId(@PathVariable("id") int id) {
        return animalRepository.findById(id).orElse(null);
    }

    @DeleteMapping("/deletar/{id}")
    public void deletarAnimal(@PathVariable("id") int id) {
        animalRepository.deleteById(id);
    }
}
